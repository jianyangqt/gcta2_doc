#include <gtest/gtest.h>
#include "Covar.h"
#include <string>
#include <iostream>
using std::string;
using std::cout;

extern int test_argc;
extern char** test_argv;

#include <map>
using std::map;

TEST(CovarLib, validStat){

   // EXPECT_TRUE(false) << "test: " << std::scientific << StatLib::pchisqd1(300) << std::endl;
   EXPECT_TRUE(false) << "outputs:" << std::endl;
   

}

