#ifndef OLD_OPTION_H
#define OLD_OPTION_H

 void option(int option_num, char* option_str[]);

#endif
