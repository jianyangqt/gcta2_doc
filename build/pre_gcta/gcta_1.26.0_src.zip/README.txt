PROGRAM: GCTA

DESCRIPTION: Genome-wide Complex Trait Analysis

AUTHOR: Jian Yang

CONTACT: jian.yang@uq.edu.au

YEAR: 2010-2013

DOCUMENTATION: http://www.complextraitgenomics.com/software/gcta/

Please see the file "HowToCompile.txt" for a step-by-step instruction to compile the
source code.
